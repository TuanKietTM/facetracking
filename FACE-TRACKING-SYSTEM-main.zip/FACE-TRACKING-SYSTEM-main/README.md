Modules Used:-
1. pyfirmata :- pip install pyFirmata

2. Numpy :- pip install numpy

3. Cv2 :- pip install opencv-python


MAKE SURE TO USE Python 3.10 as INTERPRETER

